# College Student Management System - GUI

A real Java Swing desktop application.

## Features
- Dashboard
- Student add/edit/delete/search/details
- Course management
- Enrollment management
- Attendance records and percentages
- Marks, letter grades and GPA
- Fee records and payments
- Reports
- Local persistent storage

## Requirements
Java JDK 17+.

## Run in PowerShell
From this folder:

    javac (Get-ChildItem -Filter *.java).FullName
    java Main

Or open the folder in VS Code and run Main.java.

The application creates `college_gui_data` automatically and stores its data there.
